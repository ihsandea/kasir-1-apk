[app]
title = Kasir Ihsan
package.name = kasirihsan
package.domain = org.ihsan
source.dir =.
source.include_exts = py,png,jpg,kv,atlas,ttf,json,txt
version = 1.0
requirements = python3,kivy==2.2.0,kivymd==1.1.1,pillow
android.permissions = INTERNET,WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE
android.api = 33
android.archs = arm64-v8a
[buildozer]
log_level = 2
