import os
from datetime import datetime

# === PENGATURAN ===
FILE_TABUNGAN = "catatan_tabungan.txt"
FILE_TARGET = "target.txt"
PASSWORD = "922004" # Ganti biar aman

KATEGORI_MASUK = ["Gaji", "Jual Kasir", "Bonus", "Lainnya"]
KATEGORI_KELUAR = ["Jajan", "Belanja", "Bensin", "Kuota", "Lainnya"]

# === WARNA ===
W = {
    'H': '\033[92m', # Hijau = Masuk
    'M': '\033[91m', # Merah = Keluar
    'K': '\033[93m', # Kuning = Judul
    'B': '\033[94m', # Biru = Info
    'C': '\033[96m', # Cyan = Garis
    'R': '\033[0m', # Reset
    'T': '\033[1m' # Tebel
}

def cek_password():
    os.system('clear')
    if input(f"{W['K']}Password: {W['R']}")!= PASSWORD:
        print(f"{W['M']}Salah san.{W['R']}"); exit()

def baca_target():
    if os.path.exists(FILE_TARGET):
        try: return int(open(FILE_TARGET).read())
        except: return 0
    return 0

def simpan_target(jumlah):
    open(FILE_TARGET, "w").write(str(jumlah))

def baca_saldo():
    saldo = 0; riwayat = []
    if not os.path.exists(FILE_TABUNGAN): return 0, []
    for baris in open(FILE_TABUNGAN):
        d = baris.strip().split("|")
        if len(d) == 5:
            tgl, tipe, jml, kat, ket = d
            saldo += int(jml) if tipe == "MASUK" else -int(jml)
            riwayat.append(d)
    return saldo, riwayat

def simpan_transaksi(tipe, jumlah, kategori, ket):
    tgl = datetime.now().strftime("%d-%m-%Y %H:%M")
    open(FILE_TABUNGAN, "a").write(f"{tgl}|{tipe}|{jumlah}|{kategori}|{ket}\n")

def hapus_terakhir():
    _, r = baca_saldo()
    if not r: return False
    open(FILE_TABUNGAN, "w").writelines(["|".join(i)+"\n" for i in r[:-1]])
    return True

def rp(angka): return f"Rp{angka:,}".replace(",", ".")

def bar_target(saldo, target):
    if target == 0: return f"{W['B']}[Belum ada target]{W['R']}"
    p = min(100, int(saldo/target*100))
    isi = f"{W['H']}{'█'*(p//5)}{W['R']}{'░'*(20-p//5)}"
    w_p = W['H'] if p >= 100 else W['K']
    return f"[{isi}] {w_p}{p}%{W['R']}"

def pilih_kat(list_kat):
    print(f"\n{W['B']}Pilih Kategori:{W['R']}")
    for i, k in enumerate(list_kat, 1): print(f"{W['C']}{i}.{W['R']} {k}")
    while True:
        try: return list_kat[int(input(f"{W['K']}No: {W['R']}"))-1]
        except: print(f"{W['M']}Nomor bener san.{W['R']}")

def lap_bulanan(r):
    bln = datetime.now().strftime("%m-%Y")
    masuk = sum(int(j) for t,ti,j,_,_ in r if bln in t and ti=="MASUK")
    keluar = sum(int(j) for t,ti,j,_,_ in r if bln in t and ti=="KELUAR")
    return masuk, keluar

def export(saldo, target):
    with open("struk_tabungan.txt", "w") as f:
        f.write(f"=== STRUK TABUNGAN IHSAN ===\n")
        f.write(f"{datetime.now().strftime('%d-%m-%Y %H:%M')}\n")
        f.write(f"Saldo: {rp(saldo)}\nTarget: {rp(target)}\n")
    print(f"\n{W['H']}Struk disimpan.{W['R']}")

# === TAMPILAN BARU - CUMA GARIS ATAS BAWAH ===
def menu():
    cek_password()
    while True:
        os.system('clear')
        saldo, r = baca_saldo()
        target = baca_target()
        m_bln, k_bln = lap_bulanan(r)

        # GARIS TEBEL DOANG. GAK ADA TIANG SAMPING.
        G = f"{W['C']}{'═'*37}{W['R']}"

        print(G)
        print(f" {W['T']}{W['K']}TABUNGAN IHSAN V2.3 STRUK{W['R']}")
        print(G)
        print(f" SALDO : {W['H']}{rp(saldo)}{W['R']}")
        print(f" TARGET : {W['K']}{rp(target)}{W['R']}")
        print(f" {bar_target(saldo, target)}")
        print(G)
        print(f" Bulan Ini: {W['H']}+{rp(m_bln)}{W['R']} {W['M']}-{rp(k_bln)}{W['R']}")
        print(G)
        print(f" {W['H']}[1] Uang MASUK{W['R']} {W['K']}[5] Set Target{W['R']}")
        print(f" {W['M']}[2] Uang KELUAR{W['R']} {W['B']}[6] Hapus Terakhir{W['R']}")
        print(f" {W['B']}[3] 5 Transaksi{W['R']} {W['B']}[7] Export Struk{W['R']}")
        print(f" {W['B']}[4] Riwayat{W['R']} {W['M']}[8] Keluar{W['R']}")
        print(G)

        p = input(f"\n{W['K']}Pilih 1-8: {W['R']}")

        if p in ["1","2"]:
            tipe, warna, list_kat = ("MASUK", W['H'], KATEGORI_MASUK) if p=="1" else ("KELUAR", W['M'], KATEGORI_KELUAR)
            os.system('clear'); print(f"{warna}=== UANG {tipe} ==={W['R']}")
            try:
                jml = int(input("Jumlah Rp: "))
                kat = pilih_kat(list_kat)
                ket = input("Keterangan: ")
                simpan_transaksi(tipe, jml, kat, ket)
                print(f"\n{W['H']}Sukses.{W['R']}")
            except: print(f"\n{W['M']}Jumlah harus angka.{W['R']}")
            input(f"{W['B']}Enter...{W['R']}")

        elif p == "3":
            os.system('clear'); print(f"{W['K']}=== 5 TERAKHIR ==={W['R']}")
            if not r: print("Kosong")
            else:
                for t,ti,j,k,ke in r[-5:]:
                    w = W['H'] if ti=="MASUK" else W['M']; s = "+" if ti=="MASUK" else "-"
                    print(f"{t} | {w}{s}{rp(int(j))}{W['R']} | {k} | {ke}")
            input(f"{W['B']}Enter...{W['R']}")

        elif p == "4":
            os.system('clear'); print(f"{W['K']}=== SEMUA RIWAYAT ==={W['R']}")
            if not r: print("Kosong")
            else:
                for t,ti,j,k,ke in r:
                    w = W['H'] if ti=="MASUK" else W['M']; s = "+" if ti=="MASUK" else "-"
                    print(f"{t} | {w}{s}{rp(int(j))}{W['R']} | {k} | {ke}")
            input(f"{W['B']}Enter...{W['R']}")

        elif p == "5":
            os.system('clear')
            try: simpan_target(int(input("Target Rp: "))); print(f"{W['H']}Tersimpan.{W['R']}")
            except: print(f"{W['M']}Harus angka.{W['R']}")
            input(f"{W['B']}Enter...{W['R']}")

        elif p == "6":
            os.system('clear')
            print(f"{W['H']}Dihapus.{W['R']}" if hapus_terakhir() else f"{W['M']}Gak ada data.{W['R']}")
            input(f"{W['B']}Enter...{W['R']}")

        elif p == "7":
            os.system('clear'); export(saldo, target); input(f"{W['B']}Enter...{W['R']}")

        elif p == "8": print(f"{W['K']}Dadah san.{W['R']}"); break
        else: input(f"{W['M']}1-8 doang san. Enter...{W['R']}")

if __name__ == "__main__":
    menu()
