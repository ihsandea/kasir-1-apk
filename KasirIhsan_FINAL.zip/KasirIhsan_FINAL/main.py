import datetime
import os
import hashlib
import socket
import re
import shutil
from datetime import timedelta

# LV 13.8 FINAL - LAYAR HP KENTANG EDITION
LAPORAN = "laporan.txt"
FILE_MENU = "menu.txt"

# WARNA ANSI
HIJAU = '\033[92m'
KUNING = '\033[93m'
BIRU = '\033[94m'
MERAH = '\033[91m'
EMAS = '\033[33m'
PUTIH = '\033[97m'
TEBAL = '\033[1m'
RESET = '\033[0m'

def clear():
    os.system('clear')

# GARIS PINTER NGIKUTIN LAYAR
def garis(warna=PUTIH, tebal=False, karakter='-'):
    try:
        lebar = shutil.get_terminal_size().columns
        if lebar > 42:
            lebar = 42
        elif lebar < 20:
            lebar = 20
    except:
        lebar = 42

    style = TEBAL if tebal else ''
    print(f"{style}{warna}{karakter * lebar}{RESET}")

def format_rp(angka):
    return f"{int(angka):,}".replace(",", ".")

# INPUT ANGKA ANTI JEMPOL BELEPOTAN
def input_angka(prompt, default=1, tipe=int, boleh_nol=False, wajib=False):
    while True:
        try:
            raw = input(f"{TEBAL}{prompt}{RESET}").strip()
            if raw == "":
                if wajib:
                    print(f"{TEBAL}{MERAH}>> Wajib diisi Bang!{RESET}")
                    continue
                return default

            if tipe == float:
                raw = raw.replace(",", ".")
                angka_ketemu = re.findall(r'[0-9.]+', raw)
            else:
                angka_ketemu = re.findall(r'[0-9]+', raw)

            if not angka_ketemu:
                raise ValueError

            raw = angka_ketemu[0]

            if tipe == float and raw.count('.') > 1:
                raise ValueError

            nilai = tipe(raw)

            if not boleh_nol and nilai <= 0:
                print(f"{TEBAL}{MERAH}>> Gak boleh 0 atau minus!{RESET}")
                continue
            if boleh_nol and nilai < 0:
                print(f"{TEBAL}{MERAH}>> Gak boleh minus!{RESET}")
                continue
            return nilai
        except:
            print(f"{TEBAL}{MERAH}>> Angka aja Bang! Contoh: 1 atau 0.5{RESET}")

def cek_lisensi():
    FILE_LISENSI = ".lisensi_warung"
    KODE_MASTER = "KASIRGUA2026" # WAJIB GANTI! KODE RAHASIA LU
    NO_WA = "08xx-xxxx-xxxx" # WAJIB GANTI! NOMOR WA LU
    MASA_LANGGANAN_HARI = 365

    try:
        id_hp = hashlib.md5(socket.gethostname().encode()).hexdigest()[:8].upper()
    except:
        id_hp = "WARUNG01"

    if os.path.exists(FILE_LISENSI):
        with open(FILE_LISENSI, "r") as f:
            isi = f.read().strip().split("|")
            if len(isi) == 2 and isi[0] == KODE_MASTER + id_hp:
                tgl_aktivasi = datetime.datetime.strptime(isi[1], "%Y-%m-%d")
                tgl_kadaluarsa = tgl_aktivasi + timedelta(days=MASA_LANGGANAN_HARI)
                sisa_hari = (tgl_kadaluarsa - datetime.datetime.now()).days

                if sisa_hari > 0:
                    if sisa_hari < 30:
                        clear()
                        garis(KUNING, tebal=True, karakter='=')
                        print(f"{TEBAL}{KUNING} LISENSI AKTIF | Sisa {sisa_hari} Hari{RESET}")
                        print(f"{TEBAL} Berakhir tgl: {tgl_kadaluarsa.strftime('%d-%b-%Y')}{RESET}")
                        print(f"{TEBAL} Hubungi {NO_WA} untuk perpanjang{RESET}")
                        garis(KUNING, tebal=True, karakter='=')
                        input("Pencet Enter untuk lanjut...")
                    return True
                else:
                    clear()
                    garis(MERAH, tebal=True, karakter='=')
                    print(f"{TEBAL}{MERAH} MASA LANGGANAN HABIS{RESET}")
                    garis(MERAH, tebal=True, karakter='=')
                    print(f"{TEBAL} Lisensi berakhir: {tgl_kadaluarsa.strftime('%d-%b-%Y')}{RESET}")
                    print(f"{TEBAL} ID Mesin Anda: {id_hp}{RESET}")
                    print(f"{TEBAL} Hubungi WA: {NO_WA} untuk perpanjang{RESET}")
                    garis(MERAH, tebal=True, karakter='=')
                    kode = input("Masukkan kode perpanjang: ")
                    if kode == KODE_MASTER + id_hp:
                        tgl_baru = datetime.datetime.now().strftime("%Y-%m-%d")
                        with open(FILE_LISENSI, "w") as f:
                            f.write(f"{KODE_MASTER + id_hp}|{tgl_baru}")
                        clear()
                        print(f"{TEBAL}{HIJAU}PERPANJANGAN BERHASIL! LANGGANAN AKTIF 1 TAHUN.{RESET}")
                        input("Pencet Enter untuk masuk kasir...")
                        return True
                    else:
                        print(f"{TEBAL}{MERAH}Kode salah. Aplikasi akan ditutup.{RESET}")
                        exit()

    FILE_AWAL = ".awal"
    if not os.path.exists(FILE_AWAL):
        with open(FILE_AWAL, "w") as f:
            f.write(datetime.datetime.now().strftime("%Y-%m-%d"))
        clear()
        garis(EMAS, tebal=True, karakter='=')
        print(f"{TEBAL}{EMAS} SELAMAT DATANG DI KASIR WARUNG{RESET}")
        garis(EMAS, tebal=True, karakter='=')
        print(f"{TEBAL} ID Mesin Anda: {id_hp}{RESET}")
        print(f"{TEBAL}{HIJAU} Anda mendapat Trial Gratis 7 Hari{RESET}")
        print(f"{TEBAL} Setelah itu hubungi kami untuk aktivasi{RESET}")
        garis(EMAS, tebal=True, karakter='=')
        input("Pencet Enter untuk mulai...")
        return True

    with open(FILE_AWAL, "r") as f:
        tgl_awal = datetime.datetime.strptime(f.read().strip(), "%Y-%m-%d")
    sisa_trial = 7 - (datetime.datetime.now() - tgl_awal).days

    if sisa_trial <= 0:
        clear()
        garis(MERAH, tebal=True, karakter='=')
        print(f"{TEBAL}{MERAH} MASA TRIAL HABIS{RESET}")
        garis(MERAH, tebal=True, karakter='=')
        print(f"{TEBAL} ID Mesin Anda: {id_hp}{RESET}")
        print(f"{TEBAL} Hubungi WA: {NO_WA}{RESET}")
        print(f"{TEBAL} Kirim ID Mesin di atas untuk aktivasi{RESET}")
        garis(MERAH, tebal=True, karakter='=')
        kode = input("Masukkan kode aktivasi: ")
        if kode == KODE_MASTER + id_hp:
            tgl_aktivasi = datetime.datetime.now().strftime("%Y-%m-%d")
            with open(FILE_LISENSI, "w") as f:
                f.write(f"{KODE_MASTER + id_hp}|{tgl_aktivasi}")
            clear()
            print(f"{TEBAL}{HIJAU}AKTIVASI BERHASIL! LANGGANAN AKTIF 1 TAHUN.{RESET}")
            input("Pencet Enter untuk masuk kasir...")
            return True
        else:
            print(f"{TEBAL}{MERAH}Kode salah. Aplikasi akan ditutup.{RESET}")
            exit()
    else:
        clear()
        print(f"{TEBAL}{BIRU}== ID Mesin: {id_hp} | Sisa Trial: {sisa_trial} Hari =={RESET}")
        input("Pencet Enter...")

    return True

def load_menu():
    menu = {}
    if not os.path.exists(FILE_MENU):
        with open(FILE_MENU, "w") as f:
            f.write("Gorengan,1000,biji\n")
            f.write("Kopi Sachet,2000,biji\n")
            f.write("Gula Pasir,16000,kg\n")
            f.write("Bawang Merah,35000,kg\n")
            f.write("Telur,2000,biji\n")

    with open(FILE_MENU, "r") as f:
        for i, baris in enumerate(f, 1):
            try:
                nama, harga, satuan = baris.strip().split(",")
                menu[i] = {"nama": nama, "harga": int(harga), "satuan": satuan}
            except: pass
    return menu

def save_menu(menu):
    with open(FILE_MENU, "w") as f:
        for item in menu.values():
            f.write(f"{item['nama']},{item['harga']},{item['satuan']}\n")

def itung_hari_ini():
    total = 0
    hari_ini = datetime.datetime.now().strftime("%d-%b-%Y")
    try:
        with open(LAPORAN, "r") as f:
            isi = f.read()
            transaksi = isi.split("\n\n")
            for t in transaksi:
                if hari_ini in t:
                    for baris in t.split("\n"):
                        if "TOTAL:" in baris:
                            total += int(baris.split("Rp")[1].replace(".", ""))
    except: pass
    return total

def itung_kemarin():
    total = 0
    kemarin = (datetime.datetime.now() - timedelta(days=1)).strftime("%d-%b-%Y")
    try:
        with open(LAPORAN, "r") as f:
            isi = f.read()
            transaksi = isi.split("\n\n")
            for t in transaksi:
                if kemarin in t:
                    for baris in t.split("\n"):
                        if "TOTAL:" in baris:
                            total += int(baris.split("Rp")[1].replace(".", ""))
    except: pass
    return total

def setting_menu():
    while True:
        menu = load_menu()
        clear()
        garis(EMAS, tebal=True, karakter='=')
        print(f"{TEBAL}{EMAS} PENGATURAN MENU DAGANGAN{RESET}")
        garis(EMAS, tebal=True, karakter='=')

        print(f" {TEBAL}{BIRU}1. Ubah Harga Barang{RESET}")
        print(f" {TEBAL}{BIRU}2. Tambah Barang Baru{RESET}")
        print(f" {TEBAL}{BIRU}3. Hapus Barang{RESET}")
        print(f" {TEBAL}{MERAH}0. Kembali ke Kasir{RESET}")
        garis(EMAS)
        print(f"{TEBAL}Daftar saat ini:{RESET}")
        for no, item in menu.items():
            print(f" {TEBAL}{no}.{RESET} {item['nama']} - {HIJAU}Rp{format_rp(item['harga'])}/{item['satuan']}{RESET}")
        garis()

        pilih = input(f"{TEBAL}Pilih Menu Setting: {RESET}")

        if pilih == "0": break
        elif pilih == "1":
            no = input_angka("Mau ubah harga no berapa? ", default=0, tipe=int)
            if no in menu:
                item = menu[no]
                print(f"\n{TEBAL}Harga {item['nama']} sekarang: {HIJAU}Rp{format_rp(item['harga'])}{RESET}")
                harga_baru = input_angka("Masukkan harga baru [angka saja]: Rp", default=item['harga'], tipe=int)
                menu[no]['harga'] = harga_baru
                save_menu(menu)
                print(f"{TEBAL}{HIJAU}>> Harga berhasil diubah!{RESET}")
            else:
                print(f"{TEBAL}{MERAH}>> Nomor gak ada{RESET}")
            input("Pencet Enter lanjut...")
        elif pilih == "2":
            print(f"\n{TEBAL}{EMAS}=== TAMBAH BARANG BARU ==={RESET}")
            nama = input(f"{TEBAL}Nama barang: {RESET}").strip()
            if not nama: continue
            harga = input_angka("Harga per satuan [angka saja]: Rp", default=1000, tipe=int)

            print(f"{TEBAL}Pilih satuan:{RESET}")
            print(f" {TEBAL}1. Biji / Pcs / Sachet{RESET}")
            print(f" {TEBAL}2. Kg{RESET}")
            print(f" {TEBAL}3. Ons{RESET}")
            print(f" {TEBAL}4. Liter / Bungkus{RESET}")
            pilih_satuan = input_angka("Pilih [1/2/3/4]", default=1, tipe=int)
            satuan_map = {1: "biji", 2: "kg", 3: "ons", 4: "liter"}
            satuan = satuan_map.get(pilih_satuan, "biji")

            no_baru = max(menu.keys()) + 1 if menu else 1
            menu[no_baru] = {"nama": nama, "harga": harga, "satuan": satuan}
            save_menu(menu)
            print(f"{TEBAL}{HIJAU}>> {nama} berhasil ditambah! Rp{format_rp(harga)}/{satuan}{RESET}")
            input("Pencet Enter lanjut...")
        elif pilih == "3":
            no = input_angka("Mau hapus barang no berapa? ", default=0, tipe=int)
            if no in menu:
                nama_hapus = menu[no]['nama']
                yakin = input(f"{TEBAL}{KUNING}Yakin hapus {nama_hapus}? [y/n]: {RESET}").lower()
                if yakin == 'y':
                    del menu[no]
                    save_menu(menu)
                    print(f"{TEBAL}{HIJAU}>> {nama_hapus} berhasil dihapus!{RESET}")
            else:
                print(f"{TEBAL}{MERAH}>> Nomor gak ada{RESET}")
            input("Pencet Enter lanjut...")
        else:
            print(f"{TEBAL}{MERAH}>> Pilih 0-3 aja Bang{RESET}")
            input("Pencet Enter lanjut...")

def main():
    cek_lisensi()
    keranjang = []
    while True:
        MENU = load_menu()
        clear()
        garis(EMAS, tebal=True, karakter='=')
        print(f"{TEBAL}{EMAS} KASIR WARUNG V4.8 FINAL{RESET}")
        print(f"{TEBAL}{EMAS} ANTI JEMPOL BELEPOTAN EDITION{RESET}")
        garis(EMAS, tebal=True, karakter='=')
        for no, item in MENU.items():
            print(f" {TEBAL}{PUTIH}{no}. {item['nama']:<15}{RESET} {HIJAU}Rp{format_rp(item['harga'])}/{item['satuan']}{RESET}")
        garis(EMAS)

        if keranjang:
            print(f"{TEBAL}{KUNING}KERANJANG:{RESET}")
            total_keranjang = 0
            for i, item in enumerate(keranjang, 1):
                subtotal = int(item['harga'] * item['qty'])
                print(f" {TEBAL}{i}.{RESET} {item['nama']} {item['qty']}{item['satuan']} = {HIJAU}Rp{format_rp(subtotal)}{RESET}")
                total_keranjang += subtotal
            print(f" {TEBAL}Subtotal: {KUNING}Rp{format_rp(total_keranjang)}{RESET}")
            garis()

        print(f" {TEBAL}Hari Ini: {KUNING}Rp{format_rp(itung_hari_ini())}{RESET} | Kemarin: {HIJAU}Rp{format_rp(itung_kemarin())}{RESET}")
        garis(EMAS)
        print(f" {TEBAL}{BIRU}B. Bayar{RESET} | {TEBAL}{MERAH}K. Keluar{RESET}")
        if keranjang:
            print(f" {TEBAL}{BIRU}H. Hapus Barang Keranjang{RESET}")
        print(f" {TEBAL}{BIRU}L. Lihat Laporan Hari Ini{RESET}")
        print(f" {TEBAL}{BIRU}S. Pengaturan Menu Dagangan{RESET}")
        garis(EMAS)

        pilih = input(f"{TEBAL}Pilih No Barang / Command: {RESET}").strip().lower()

        if pilih == "k":
            if keranjang:
                clear()
                garis(MERAH, tebal=True, karakter='=')
                print(f"{TEBAL}{MERAH} PERINGATAN!{RESET}")
                print(f"{TEBAL} Masih ada {len(keranjang)} barang di keranjang!{RESET}")
                print(f"{TEBAL} Total: {KUNING}Rp{format_rp(sum(int(item['harga']*item['qty']) for item in keranjang))}{RESET}")
                garis(MERAH, tebal=True, karakter='=')
                yakin = input(f"{TEBAL}{KUNING}Yakin mau keluar? Transaksi bakal hilang [y/n]: {RESET}").lower()
                if yakin!= 'y':
                    continue
            print(f"{TEBAL}Makasih Bang. Aplikasi ditutup.{RESET}")
            break
        elif pilih == "s":
            setting_menu()
        elif pilih == "l":
            clear()
            garis(EMAS, tebal=True, karakter='=')
            print(f"{TEBAL}{EMAS} LAPORAN PENJUALAN HARI INI{RESET}")
            garis(EMAS, tebal=True, karakter='=')
            hari_ini = datetime.datetime.now().strftime("%d-%b-%Y")
            total_harian = 0
            ada_transaksi = False
            no_struk = 1
            try:
                with open(LAPORAN, "r") as f:
                    isi = f.read()
                    transaksi = isi.split("\n\n")
                    for t in transaksi:
                        if hari_ini in t and "===" in t:
                            print(f"{TEBAL}{BIRU}--- STRUK #{no_struk} ---{RESET}")
                            print(t)
                            ada_transaksi = True
                            no_struk += 1
                            for baris in t.split("\n"):
                                if "TOTAL:" in baris:
                                    total_harian += int(baris.split("Rp")[1].replace(".", ""))
                        elif hari_ini in t:
                            print(t)
                            ada_transaksi = True
                            for baris in t.split("\n"):
                                if "TOTAL:" in baris:
                                    total_harian += int(baris.split("Rp")[1].replace(".", ""))
            except: pass
            if not ada_transaksi:
                print(f"{TEBAL} Belum ada transaksi hari ini{RESET}")
            garis(EMAS, tebal=True, karakter='=')
            print(f" {TEBAL}{KUNING}TOTAL OMSET HARI INI: Rp{format_rp(total_harian)}{RESET}")
            garis(EMAS, tebal=True, karakter='=')
            input("\nPencet Enter untuk kembali...")
        elif pilih == "h" and keranjang:
            clear()
            garis(KUNING, tebal=True, karakter='=')
            print(f"{TEBAL}{KUNING} HAPUS BARANG DARI KERANJANG{RESET}")
            garis(KUNING, tebal=True, karakter='=')
            for i, item in enumerate(keranjang, 1):
                subtotal = int(item['harga'] * item['qty'])
                print(f" {TEBAL}{i}.{RESET} {item['nama']} {item['qty']}{item['satuan']} = {HIJAU}Rp{format_rp(subtotal)}{RESET}")
            garis()
            no_hapus = input_angka("Mau hapus no berapa? [0=Batal]", default=0, tipe=int, boleh_nol=True)
            if 1 <= no_hapus <= len(keranjang):
                nama_hapus = keranjang[no_hapus-1]['nama']
                del keranjang[no_hapus-1]
                print(f"{TEBAL}{HIJAU}>> {nama_hapus} dihapus dari keranjang!{RESET}")
            input("Pencet Enter lanjut...")
        elif pilih == "b":
            if not keranjang:
                print(f"{TEBAL}{MERAH}>> Keranjang masih kosong!{RESET}")
                input("Pencet Enter lanjut...")
                continue
            clear()
            garis(HIJAU, tebal=True, karakter='=')
            print(f"{TEBAL}{HIJAU} STRUK BELANJA{RESET}")
            garis(HIJAU, tebal=True, karakter='=')
            total = 0
            waktu = datetime.datetime.now().strftime("%d-%b-%Y %H:%M")
            detail_laporan = f"=== {waktu} ===\n"
            for item in keranjang:
                nama = item['nama']
                qty = item['qty']
                satuan = item['satuan']
                harga = item['harga']
                subtotal = int(harga * qty)
                print(f" {TEBAL}{PUTIH}{nama:<15}{RESET} {qty}{satuan:<5} {HIJAU}Rp{format_rp(subtotal)}{RESET}")
                detail_laporan += f"{nama} {qty}{satuan} = Rp{format_rp(subtotal)}\n"
                total += subtotal
            garis(HIJAU, tebal=True, karakter='=')
            print(f" {TEBAL}{KUNING}TOTAL : Rp{format_rp(total)}{RESET}")
            garis(HIJAU, tebal=True, karakter='=')

            while True:
                uang_bayar_input = input(f"{TEBAL} Uang Bayar [angka saja]: Rp{RESET}").strip()

                print('\033[1A\033[K', end='')
                print('\033[1A\033[K', end='')

                if uang_bayar_input == "":
                    print(f"{TEBAL}{MERAH}>> Wajib diisi Bang!{RESET}")
                    continue

                try:
                    angka_ketemu = re.findall(r'[0-9]+', uang_bayar_input)
                    if not angka_ketemu:
                        raise ValueError
                    uang_bayar = int(angka_ketemu[0])
                    if uang_bayar < total:
                        print(f"{TEBAL}{MERAH}>> Kurang Rp{format_rp(total - uang_bayar)}!{RESET}")
                        continue
                    break
                except:
                    print(f"{TEBAL}{MERAH}>> Angka aja! Contoh: 150000{RESET}")

            print(f"{TEBAL} Uang Bayar: {HIJAU}Rp{format_rp(uang_bayar)}{RESET}")
            kembalian = uang_bayar - total
            print(f" {TEBAL}{HIJAU}Kembalian: Rp{format_rp(kembalian)}{RESET}")
            detail_laporan += f"Bayar: Rp{format_rp(uang_bayar)} | Kembali: Rp{format_rp(kembalian)}\n"

            garis(HIJAU, tebal=True, karakter='=')
            print(f" {TEBAL}{waktu}{RESET}")
            print(f" {TEBAL}{EMAS}Makasih udah belanja :){RESET}")
            garis(HIJAU, tebal=True, karakter='=')
            detail_laporan += f"TOTAL: Rp{format_rp(total)}\n\n"
            with open(LAPORAN, "a") as f:
                f.write(detail_laporan)
            input("\nPencet Enter buat transaksi baru...")
            keranjang = []
        elif pilih.isdigit() and int(pilih) in MENU:
            item_dipilih = MENU[int(pilih)]
            satuan = item_dipilih['satuan']

            if satuan in ["kg", "ons", "liter"]:
                qty = input_angka(f">> {item_dipilih['nama']} berapa {satuan}? [1]", default=1.0, tipe=float)
            else:
                qty = input_angka(f">> {item_dipilih['nama']} berapa {satuan}? [1]", default=1, tipe=int)

            keranjang.append({
                'nama': item_dipilih['nama'],
                'harga': item_dipilih['harga'],
                'qty': qty,
                'satuan': satuan
            })
            print(f"{TEBAL}{HIJAU}>> {qty}{satuan} {item_dipilih['nama']} masuk keranjang{RESET}")
            input("Pencet Enter lanjut...")
        else:
            print(f"{TEBAL}{MERAH}>> Pilih nomor barang / B/L/H/S/K Bang{RESET}")
            input("Pencet Enter lanjut...")

if __name__ == "__main__":
    main()
